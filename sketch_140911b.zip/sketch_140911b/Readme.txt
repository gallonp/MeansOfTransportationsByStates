Readme
1. To run this infoViz,please import geoMap and ControlP 5 libraries.
2. We have added another column in commuterData.csv, please use the csv file we uploaded.
3. You can click on the map to select which state to show on Viz1.
4. For Viz1, the littleMan barchart shows the percetage of each category. 1 little man represents 1 percentage. (For instance, if drove alone has 81 little men, it means 81% people of that state drove alone.)
5. For Viz 1, you can mouseover the label to get the detail number.
6. For Viz 2, you can select "percentage" or "number" by clicking the button accordingly.
7. For Viz 2, you can filter the information by changing the range.
8. For Viz 2, you can mouseover the barchart to get the detail number. We did not implement details on demand on the pie chart, since it already showed the detail number beneath each pie chart.
9. For Viz 2, there is linking inside the Viz. The corresponding piechart/barchart will be highlighted if you mouseover one chart.(white border)
10.For Viz 2, there is linking between Viz 1 and Viz2. If you click on one state on the map, the corresponding piechart/barchart will be highlighted.(pink border)
